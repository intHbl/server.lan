
[Administrator]
  Email/user: admin@admin.lan
  password: admin

[service]
  seahub : 8000
  seafile: 8082
  webdav:  8080

[http.proxy]
  seahub & seafile : 80
                        ----> 8000,8082
  webdav : 8080  ----->8080

