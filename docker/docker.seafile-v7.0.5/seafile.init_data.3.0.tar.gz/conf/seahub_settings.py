# -*- coding: utf-8 -*-
SECRET_KEY = "i%fw^@1b_=8y6h)z$y)cze+(xonnu-lsbvh74si$uv*gj-88k5"
