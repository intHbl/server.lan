define([
    'underscore',
    'backbone',
    'common',
], function(_, Backbone, Common) {
    'use strict';

    var Invitation = Backbone.Model.extend({});

    return Invitation;
});
