define([
    'underscore',
    'backbone',
    'common'
], function(_, Backbone, Common) {
    'use strict';

    var AdminLoginLogModel = Backbone.Model.extend({});

    return AdminLoginLogModel;
});
