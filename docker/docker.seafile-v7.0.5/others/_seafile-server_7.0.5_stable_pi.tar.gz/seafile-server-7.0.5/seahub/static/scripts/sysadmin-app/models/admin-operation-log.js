define([
    'underscore',
    'backbone',
    'common',
], function(_, Backbone, Common) {
    'use strict';

    var AdminLogModel = Backbone.Model.extend({});

    return AdminLogModel;
});
