define([
    'underscore',
    'backbone',
    'common',
], function(_, Backbone, Common) {
    'use strict';

    var DeviceError = Backbone.Model.extend({});

    return DeviceError;
});
