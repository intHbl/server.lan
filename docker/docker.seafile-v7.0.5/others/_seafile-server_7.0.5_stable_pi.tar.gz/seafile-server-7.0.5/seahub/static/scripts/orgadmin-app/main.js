define([
    'orgadmin-app/router'
], function(Router){
    app.router = new Router();
    Backbone.history.start();
});
