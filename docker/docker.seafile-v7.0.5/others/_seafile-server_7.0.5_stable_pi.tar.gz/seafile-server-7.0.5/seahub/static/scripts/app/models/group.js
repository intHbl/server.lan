define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var Group = Backbone.Model.extend({});

    return Group;
});
