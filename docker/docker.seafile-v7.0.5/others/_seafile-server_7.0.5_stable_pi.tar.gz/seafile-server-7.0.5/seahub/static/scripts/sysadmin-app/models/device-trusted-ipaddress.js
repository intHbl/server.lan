define([
    'underscore',
    'backbone',
    'common'
], function(_, Backbone, Common) {
    'use strict';

    var DeviceTrustedIP = Backbone.Model.extend({});

    return DeviceTrustedIP;
})
