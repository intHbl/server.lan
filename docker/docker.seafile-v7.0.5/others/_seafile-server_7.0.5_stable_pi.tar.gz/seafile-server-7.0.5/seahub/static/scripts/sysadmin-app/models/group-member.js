define([
    'underscore',
    'backbone',
    'common'
], function(_, Backbone, Common) {

    'use strict';

    var GroupMember = Backbone.Model.extend({});

    return GroupMember;
});
