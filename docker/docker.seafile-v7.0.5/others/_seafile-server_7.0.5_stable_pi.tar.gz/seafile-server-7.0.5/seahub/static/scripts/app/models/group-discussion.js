define([
    'underscore',
    'backbone',
    'common'
], function(_, Backbone, Common) {
    'use strict';

    var GroupDiscussion = Backbone.Model.extend({});

    return GroupDiscussion;
});
